# Changelog

## 0.4.3

- Fortschrittsanzeige fuer Datei-Uploads ergaenzt.
- Ablauf-Log fuer Upload, Backup-Laden, Cache-Aktionen und Import ergaenzt.
- Indeterminierter Arbeitsstatus fuer serverseitige Backup-Extraktion und Analyse
  ergaenzt.

## 0.4.2

- Standard-Uploadlimit auf 128 GB (`131072` MB) angehoben.
- Supervisor-Optionsschema erlaubt nun `max_upload_mb` bis `131072`.

## 0.4.1

- Docker-Build repariert: nicht vorhandenes Alpine-Paket `py3-sqlite3`
  entfernt. Das Python-`sqlite3`-Modul wird ueber `python3` bereitgestellt.

## 0.4.0

- Geraete-Backups aus dem gemounteten `/backup`-Verzeichnis koennen direkt in
  der UI ausgewaehlt und analysiert werden.
- Vollstaendige Home-Assistant-Backups werden weiterhin rekursiv nach der
  Recorder-Datenbank durchsucht.
- Serverseitiges Paging und Filtern fuer Backup-Entitaeten ergaenzt.

## 0.3.0

- Optionalen Import von Long-Term-Statistics ergaenzt.
- Statistik-Mapping fuer `statistics_meta`, `statistics_short_term` und `statistics`
  anhand Quell-/Ziel-Entitaet ergaenzt.
- Doppelte Statistik-Slots werden anhand `metadata_id` und Startzeit uebersprungen.
- UI zeigt Statistik-Zeilen pro Entitaet an.
- Upload-Auswahl um `.backup` und `.tar.gz` fuer vollstaendige Home-Assistant-Backups erweitert.

## 0.2.0

- Web-UI mit Home-Assistant-Ingress ergaenzt.
- Upload und Zwischenspeicher fuer SQLite-Datenbanken und Home-Assistant-Backup-Archive ergaenzt.
- Datenbankpruefung mit SQLite-Integrity-Check ergaenzt.
- Entitaetenanalyse fuer hochgeladene Recorder-Datenbanken ergaenzt.
- Import-Workflow fuer Recorder-State-History mit Quell-/Ziel-Entitaetsmapping ergaenzt.
- Aktuelle Home-Assistant-Datenbank wird vor Schreibimport optional gesichert.

## 0.1.0

- Initiales Home-Assistant-App-Grundgeruest.
- Konfiguration fuer Dry-Run, Backup-Datei, Datenbankpfad und Log-Level.
- Platzhalter-Startskript ohne produktive Restore-Logik.
