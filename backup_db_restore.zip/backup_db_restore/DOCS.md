# Backup DB Restore

Diese App stellt eine Ingress-UI bereit, mit der eine Home-Assistant-Recorder-
Datenbank aus einem Backup hochgeladen, analysiert und teilweise in die aktuelle
Instanz importiert werden kann.

## Konfiguration

| Option | Typ | Standard | Beschreibung |
| --- | --- | --- | --- |
| `log_level` | Liste | `info` | Log-Level fuer die App-Ausgabe. |
| `database_path` | String | `/homeassistant_config/home-assistant_v2.db` | Pfad zur Home-Assistant-Datenbank im Container. |
| `max_upload_mb` | Integer | `131072` | Maximale Uploadgroesse in MB, entspricht 128 GB. |
| `create_current_db_backup` | Boolean | `true` | Erstellt vor einem Schreibimport eine SQLite-Sicherung der aktuellen DB unter `/data/current-db-backups`. |

## Eingebundene Verzeichnisse

- `/backup` ist read-only eingebunden und fuer Home-Assistant-Backups gedacht.
- `/share` ist read-write eingebunden und kann fuer manuelle Artefakte genutzt werden.
- `/homeassistant_config` ist read-write eingebunden, damit History-Daten in die
  aktuelle Recorder-Datenbank geschrieben werden koennen.
- `/data` speichert Upload-Cache und Sicherheitskopien persistent.

## Importverhalten

Die App importiert rohe State-History aus der Tabelle `states`. Optional kann sie
zusaetzlich Long-Term-Statistics aus `statistics_meta`, `statistics_short_term`
und `statistics` fuer dasselbe Quell-/Ziel-Mapping uebernehmen. Beim Import muss
eine Quell-Entitaet aus der hochgeladenen Datenbank und eine Ziel-Entitaet aus
der aktuellen Instanz ausgewaehlt werden.

Der Import schreibt keine vollstaendige Home-Assistant-Sicherung zurueck. Er
uebernimmt State-Zeilen, mappt `metadata_id` auf die Ziel-Entitaet und kopiert
referenzierte `state_attributes`, soweit beide Datenbankschemata kompatibel sind.
Bereits vorhandene Zielzeilen mit gleichem Zeitstempel werden standardmaessig
uebersprungen.

Beim Statistikimport wird `statistics_meta.statistic_id` auf die Ziel-Entitaet
gemappt. Bereits vorhandene Statistik-Zeilen mit gleicher Startzeit werden
uebersprungen.

Vollstaendige Home-Assistant-Backups koennen hochgeladen werden, solange sie als
Tar-Archiv vorliegen. Die App durchsucht das Archiv und verschachtelte
`tar`/`tar.gz`/`tgz`-Dateien nach einer SQLite-Datenbank, bevorzugt nach
`home-assistant_v2.db`.

Alternativ kann in der UI ein bereits auf dem Home-Assistant-Geraet gespeichertes
Backup aus `/backup` ausgewaehlt werden. Die App liest dieses Backup read-only,
extrahiert nur die gefundene Recorder-Datenbank in den Cache und fuehrt danach
dieselben Analyse- und Importaktionen aus wie bei einem Upload.

Die Entitaetenliste wird serverseitig paginiert und gefiltert, damit auch grosse
Recorder-Datenbanken mit vielen Entitaeten bedienbar bleiben.

Bei Uploads zeigt die UI den Browser-Uploadfortschritt an. Fuer serverseitige
Aktionen wie Backup-Extraktion, Cache-Aktualisierung und Import wird ein
Arbeitsstatus mit Ablauf-Log angezeigt.

## Sicherheitshinweise

1. Vor produktivem Import sollte ein Home-Assistant-Backup vorhanden sein.
2. Wenn die aktuelle Datenbank gesperrt ist, bricht der Import ab.
3. Bei sehr grossen Datenbanken kann die Analyse laenger dauern.
4. Bei Schema-Unterschieden zwischen alter und aktueller Home-Assistant-Version
   kann ein Import fehlschlagen.
