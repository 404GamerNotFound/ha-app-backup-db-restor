# Backup DB Restore

Backup DB Restore ist eine experimentelle Home Assistant App fuer den Import von
Recorder-History aus einer hochgeladenen Backup-Datenbank.

Die App stellt eine Ingress-UI bereit. Dort kann eine SQLite-Datenbank oder ein
Home-Assistant-Backup-Archiv hochgeladen, analysiert, zwischengespeichert und per
Entitaetsmapping in die aktuelle Instanz importiert werden.

## Dateien

- `config.yaml` beschreibt die App fuer den Home Assistant Supervisor.
- `Dockerfile` baut den Container auf Basis von `ghcr.io/home-assistant/base`.
- `run.sh` ist der Einstiegspunkt der App.
- `app.py` enthaelt Webserver, Analyse und Importlogik.
- `web/` enthaelt die statische Ingress-UI.
- `DOCS.md` dokumentiert Optionen, Mounts und naechste Schritte.
