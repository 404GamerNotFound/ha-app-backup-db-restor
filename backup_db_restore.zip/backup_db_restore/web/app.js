const state = {
  sourceEntities: [],
  currentEntities: [],
  deviceBackups: [],
  sourcePage: {
    offset: 0,
    limit: 100,
    total: 0,
    filter: "",
  },
  status: null,
};

const $ = (id) => document.getElementById(id);

function appendLog(message) {
  const log = $("operationLog");
  const time = new Date().toLocaleTimeString();
  log.textContent = `${log.textContent}${log.textContent ? "\n" : ""}[${time}] ${message}`;
  log.scrollTop = log.scrollHeight;
}

function clearOperationLog() {
  $("operationLog").textContent = "";
}

function setProgress(percent, status, indeterminate = false) {
  const track = $("progressTrack");
  const bar = $("progressBar");
  track.classList.toggle("indeterminate", indeterminate);
  if (!indeterminate) {
    bar.style.width = `${Math.max(0, Math.min(100, percent))}%`;
  }
  $("progressStatus").textContent = status;
}

function finishProgress(status) {
  setProgress(100, status);
  window.setTimeout(() => setProgress(0, "Bereit"), 1200);
}

function setBusy(isBusy) {
  for (const id of [
    "uploadButton",
    "cacheButton",
    "clearCacheButton",
    "refreshBackupsButton",
    "loadBackupButton",
    "previewButton",
    "importButton",
  ]) {
    $(id).disabled = isBusy;
  }
}

function toast(message, type = "info") {
  const element = $("toast");
  element.textContent = message;
  element.className = type;
  window.clearTimeout(toast.timer);
  toast.timer = window.setTimeout(() => {
    element.textContent = "";
    element.className = "";
  }, 4500);
}

async function api(path, options = {}) {
  const response = await fetch(path, options);
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload.error || response.statusText);
  }
  return payload;
}

function uploadFileWithProgress(file) {
  return new Promise((resolve, reject) => {
    const request = new XMLHttpRequest();
    request.open("PUT", "api/upload");
    request.responseType = "json";
    request.setRequestHeader("Content-Type", "application/octet-stream");
    request.setRequestHeader("X-Filename", encodeURIComponent(file.name));

    request.upload.addEventListener("progress", (event) => {
      if (!event.lengthComputable) {
        setProgress(25, "Upload laeuft", true);
        return;
      }
      const percent = Math.round((event.loaded / event.total) * 100);
      setProgress(percent, `Upload ${percent}%`);
    });

    request.addEventListener("load", () => {
      const payload = request.response || {};
      if (request.status >= 200 && request.status < 300) {
        resolve(payload);
      } else {
        reject(new Error(payload.error || request.statusText || "Upload fehlgeschlagen"));
      }
    });

    request.addEventListener("error", () => reject(new Error("Upload fehlgeschlagen")));
    request.addEventListener("abort", () => reject(new Error("Upload abgebrochen")));
    request.send(file);
  });
}

function formatDate(value) {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString();
}

function formatBytes(value) {
  if (!value) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let size = Number(value);
  let unit = 0;
  while (size >= 1024 && unit < units.length - 1) {
    size /= 1024;
    unit += 1;
  }
  return `${size.toFixed(unit ? 1 : 0)} ${units[unit]}`;
}

function setHealth(element, ok, emptyText) {
  element.textContent = emptyText || (ok ? "In Ordnung" : "Nicht in Ordnung");
  element.className = ok ? "good" : "bad";
}

function renderStatus() {
  const status = state.status;
  if (!status) return;

  $("currentDbPath").textContent = status.options.database_path;

  const source = status.cache.analysis;
  if (source && source.exists) {
    setHealth($("sourceHealth"), Boolean(source.ok));
    $("sourceDetails").textContent = `${formatBytes(source.size_bytes)} / ${source.states_count || 0} States / ${source.statistics_count || 0} LTS`;
  } else {
    $("sourceHealth").textContent = "Keine Datei";
    $("sourceHealth").className = "muted";
    $("sourceDetails").textContent = "";
  }

  const target = status.current_database;
  if (target && target.exists) {
    setHealth($("targetHealth"), Boolean(target.ok));
    $("targetDetails").textContent = `${formatBytes(target.size_bytes)} / ${target.states_count || 0} States / ${target.statistics_count || 0} LTS`;
  } else {
    $("targetHealth").textContent = "Nicht gefunden";
    $("targetHealth").className = "bad";
    $("targetDetails").textContent = "";
  }

  $("entityCount").textContent = String(source?.entities_count || 0);
  $("historyRange").textContent = source?.first_state ? `${formatDate(source.first_state)} - ${formatDate(source.last_state)}` : "";

  const badge = $("healthBadge");
  const allOk = Boolean(source?.ok) && Boolean(target?.ok);
  badge.textContent = allOk ? "Bereit" : "Pruefen";
  badge.className = allOk ? "badge badge-good" : "badge badge-muted";
}

function renderSourceEntities() {
  const rows = state.sourceEntities
    .map((entity) => `
      <tr>
        <td><code>${entity.entity_id}</code></td>
        <td>${entity.states_count}</td>
        <td>${entity.statistics_count || 0}</td>
        <td>${formatDate(entity.first_seen || entity.first_statistic)}</td>
        <td>${formatDate(entity.last_seen || entity.last_statistic)}</td>
        <td><button class="small" data-source="${entity.entity_id}">Importieren</button></td>
      </tr>
    `)
    .join("");

  $("sourceEntities").innerHTML = rows || '<tr><td colspan="6" class="empty">Keine Entitaeten</td></tr>';

  for (const button of $("sourceEntities").querySelectorAll("button[data-source]")) {
    button.addEventListener("click", () => {
      $("sourceEntity").value = button.dataset.source;
      if (state.currentEntities.some((entity) => entity.entity_id === button.dataset.source)) {
        $("targetEntity").value = button.dataset.source;
      }
      $("targetEntity").focus();
    });
  }

  renderPager();
}

function renderPager() {
  const page = state.sourcePage;
  const from = page.total ? page.offset + 1 : 0;
  const to = Math.min(page.offset + page.limit, page.total);
  $("pageInfo").textContent = `${from}-${to} von ${page.total}`;
  $("prevPageButton").disabled = page.offset <= 0;
  $("nextPageButton").disabled = page.offset + page.limit >= page.total;
}

function renderTargetEntities() {
  $("targetEntityList").innerHTML = state.currentEntities
    .map((entity) => `<option value="${entity.entity_id}">${entity.name || entity.entity_id}</option>`)
    .join("");
}

function renderDeviceBackups() {
  const select = $("deviceBackupSelect");
  select.innerHTML = state.deviceBackups
    .map((file) => {
      const label = `${file.relative_path} (${formatBytes(file.size_bytes)}, ${formatDate(file.modified)})`;
      return `<option value="${file.id}">${label}</option>`;
    })
    .join("");
  $("backupListInfo").textContent = state.deviceBackups.length
    ? `${state.deviceBackups.length} Datei(en) in /backup`
    : "Keine Backup-Dateien in /backup gefunden";
}

async function fetchSourceEntities() {
  const params = new URLSearchParams({
    offset: String(state.sourcePage.offset),
    limit: String(state.sourcePage.limit),
    filter: state.sourcePage.filter,
  });
  const source = await api(`api/source/entities?${params.toString()}`);
  state.sourceEntities = source.entities || [];
  state.sourcePage = {
    offset: source.offset || 0,
    limit: source.limit || state.sourcePage.limit,
    total: source.total || 0,
    filter: source.filter || "",
  };
  renderSourceEntities();
}

async function refreshBackups() {
  try {
    appendLog("Backup-Liste wird aktualisiert.");
    const payload = await api("api/backups");
    state.deviceBackups = payload.files || [];
    renderDeviceBackups();
    appendLog(`${state.deviceBackups.length} Backup-Datei(en) gefunden.`);
  } catch (error) {
    appendLog(`Fehler beim Laden der Backup-Liste: ${error.message}`);
    toast(error.message, "error");
  }
}

async function refreshStatus() {
  state.status = await api("api/status");
  renderStatus();

  const current = await api("api/current/entities");
  state.currentEntities = current.entities || [];
  renderTargetEntities();

  await fetchSourceEntities();
}

async function uploadSelectedFile() {
  const file = $("fileInput").files[0];
  if (!file) {
    toast("Keine Datei ausgewaehlt", "warn");
    return;
  }
  setBusy(true);
  clearOperationLog();
  setProgress(0, "Upload startet");
  appendLog(`Upload gestartet: ${file.name} (${formatBytes(file.size)})`);
  try {
    await uploadFileWithProgress(file);
    setProgress(100, "Upload abgeschlossen");
    appendLog("Upload abgeschlossen. Datenbank wird analysiert.");
    state.sourcePage.offset = 0;
    await refreshStatus();
    appendLog("Analyse abgeschlossen und Cache aktualisiert.");
    finishProgress("Fertig");
    toast("Upload analysiert und zwischengespeichert", "success");
  } catch (error) {
    setProgress(0, "Fehler");
    appendLog(`Fehler: ${error.message}`);
    toast(error.message, "error");
  } finally {
    setBusy(false);
  }
}

async function loadDeviceBackup() {
  const fileId = $("deviceBackupSelect").value;
  if (!fileId) {
    toast("Keine Backup-Datei ausgewaehlt", "warn");
    return;
  }

  setBusy(true);
  clearOperationLog();
  setProgress(20, "Backup wird gelesen", true);
  appendLog(`Backup wird gelesen: ${fileId}`);
  try {
    await api("api/backups/load", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ file_id: fileId }),
    });
    appendLog("Recorder-Datenbank wurde aus dem Backup extrahiert.");
    setProgress(80, "Datenbank wird analysiert", true);
    state.sourcePage.offset = 0;
    await refreshStatus();
    appendLog("Analyse abgeschlossen und Cache aktualisiert.");
    finishProgress("Fertig");
    toast("Backup analysiert und zwischengespeichert", "success");
  } catch (error) {
    setProgress(0, "Fehler");
    appendLog(`Fehler: ${error.message}`);
    toast(error.message, "error");
  } finally {
    setBusy(false);
  }
}

async function refreshCache() {
  setBusy(true);
  clearOperationLog();
  setProgress(40, "Cache wird aktualisiert", true);
  appendLog("Zwischenspeicher wird neu analysiert.");
  try {
    await api("api/cache/refresh", { method: "POST" });
    state.sourcePage.offset = 0;
    await refreshStatus();
    appendLog("Zwischenspeicher aktualisiert.");
    finishProgress("Fertig");
    toast("Zwischenspeicher aktualisiert", "success");
  } catch (error) {
    setProgress(0, "Fehler");
    appendLog(`Fehler: ${error.message}`);
    toast(error.message, "error");
  } finally {
    setBusy(false);
  }
}

async function clearCache() {
  setBusy(true);
  clearOperationLog();
  setProgress(30, "Cache wird geleert", true);
  appendLog("Zwischenspeicher wird geleert.");
  try {
    await api("api/cache/clear", { method: "POST" });
    state.sourcePage.offset = 0;
    state.sourceEntities = [];
    await refreshStatus();
    appendLog("Zwischenspeicher geleert.");
    finishProgress("Fertig");
    toast("Cache geleert", "success");
  } catch (error) {
    setProgress(0, "Fehler");
    appendLog(`Fehler: ${error.message}`);
    toast(error.message, "error");
  } finally {
    setBusy(false);
  }
}

async function runImport(forceWrite) {
  const dryRun = forceWrite ? false : $("dryRun").checked;
  const payload = {
    source_entity_id: $("sourceEntity").value.trim(),
    target_entity_id: $("targetEntity").value.trim(),
    dry_run: dryRun,
    confirm: $("confirmImport").checked,
    include_statistics: $("includeStatistics").checked,
  };

  if (!payload.source_entity_id || !payload.target_entity_id) {
    toast("Quelle und Ziel fehlen", "warn");
    return;
  }
  if (!dryRun && !payload.confirm) {
    toast("Schreibimport bestaetigen", "warn");
    return;
  }

  setBusy(true);
  clearOperationLog();
  setProgress(35, dryRun ? "Import wird geprueft" : "Import laeuft", true);
  appendLog(`${dryRun ? "Pruefung" : "Import"} gestartet: ${payload.source_entity_id} -> ${payload.target_entity_id}`);
  if (payload.include_statistics) {
    appendLog("Long-Term-Statistics werden beruecksichtigt.");
  }
  $("importResult").textContent = "Laeuft...";
  try {
    const result = await api("api/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    $("importResult").textContent = JSON.stringify(result, null, 2);
    appendLog(`States: ${result.inserted} neu, ${result.skipped} uebersprungen, ${result.scanned} geprueft.`);
    if (result.statistics) {
      appendLog(`Statistik: ${result.statistics.inserted} neu, ${result.statistics.skipped} uebersprungen, ${result.statistics.scanned} geprueft.`);
    }
    await refreshStatus();
    finishProgress(dryRun ? "Pruefung fertig" : "Import fertig");
    toast(dryRun ? "Pruefung abgeschlossen" : "Import abgeschlossen", "success");
  } catch (error) {
    setProgress(0, "Fehler");
    appendLog(`Fehler: ${error.message}`);
    $("importResult").textContent = error.message;
    toast(error.message, "error");
  } finally {
    setBusy(false);
  }
}

function bindEvents() {
  $("uploadButton").addEventListener("click", uploadSelectedFile);
  $("cacheButton").addEventListener("click", refreshCache);
  $("clearCacheButton").addEventListener("click", clearCache);
  $("refreshBackupsButton").addEventListener("click", refreshBackups);
  $("loadBackupButton").addEventListener("click", loadDeviceBackup);
  $("sourceFilter").addEventListener("input", () => {
    window.clearTimeout(bindEvents.filterTimer);
    bindEvents.filterTimer = window.setTimeout(() => {
      state.sourcePage.filter = $("sourceFilter").value.trim();
      state.sourcePage.offset = 0;
      fetchSourceEntities().catch((error) => toast(error.message, "error"));
    }, 250);
  });
  $("prevPageButton").addEventListener("click", () => {
    state.sourcePage.offset = Math.max(0, state.sourcePage.offset - state.sourcePage.limit);
    fetchSourceEntities().catch((error) => toast(error.message, "error"));
  });
  $("nextPageButton").addEventListener("click", () => {
    state.sourcePage.offset += state.sourcePage.limit;
    fetchSourceEntities().catch((error) => toast(error.message, "error"));
  });
  $("pageSizeSelect").addEventListener("change", () => {
    state.sourcePage.limit = Number($("pageSizeSelect").value);
    state.sourcePage.offset = 0;
    fetchSourceEntities().catch((error) => toast(error.message, "error"));
  });
  $("previewButton").addEventListener("click", () => runImport(false));
  $("importButton").addEventListener("click", () => runImport(true));
}

bindEvents();
refreshBackups();
refreshStatus().catch((error) => toast(error.message, "error"));
